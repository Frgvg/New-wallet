-- ============================================================
-- Supabase schema for the crypto wallet app
-- Run this in Supabase Dashboard -> SQL Editor
--
-- SECURITY RULE: The database NEVER stores private keys,
-- seed phrases or signatures. Only PUBLIC data lives here:
-- user profile, wallet address, transaction cache, address book.
-- ============================================================

-- 1. Profiles: one row per authenticated user
create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  display_name text,
  created_at timestamptz default now()
);

-- 2. Wallets: public address only (key material stays on device!)
create table if not exists public.wallets (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  address text not null unique,
  label text default 'Main Wallet',
  chain text not null default 'sepolia',
  created_at timestamptz default now()
);

-- 3. Transaction cache: synced from the blockchain for display only
create table if not exists public.transactions (
  id uuid primary key default gen_random_uuid(),
  wallet_address text not null,
  tx_hash text not null,
  direction text not null check (direction in ('in', 'out')),
  from_address text not null,
  to_address text not null,
  amount_eth numeric(20, 10) not null,
  status text not null default 'pending',
  block_number bigint,
  created_at timestamptz default now(),
  unique (wallet_address, tx_hash)
);

-- 4. Address book: saved contacts for sending
create table if not exists public.address_book (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  label text not null,
  address text not null,
  created_at timestamptz default now(),
  unique (user_id, address)
);

-- ============================================================
-- Row Level Security: users can only see/modify their own rows
-- ============================================================
alter table public.profiles      enable row level security;
alter table public.wallets       enable row level security;
alter table public.transactions  enable row level security;
alter table public.address_book  enable row level security;

create policy "own profile"  on public.profiles     for all using (auth.uid() = id);
create policy "own wallets"  on public.wallets      for all using (auth.uid() = user_id);
create policy "own contacts" on public.address_book for all using (auth.uid() = user_id);

-- Transactions are keyed by public address; readable by owner,
-- inserted by owner (the app syncs them from the chain).
create policy "own transactions" on public.transactions
  for all using (
    exists (
      select 1 from public.wallets w
      where w.address = transactions.wallet_address
        and w.user_id = auth.uid()
    )
  );

-- Indexes
create index if not exists idx_wallets_user on public.wallets(user_id);
create index if not exists idx_tx_address on public.transactions(wallet_address, created_at desc);
